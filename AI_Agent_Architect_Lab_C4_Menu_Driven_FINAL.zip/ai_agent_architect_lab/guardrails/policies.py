from core.audit import audit

JAILBREAK_PATTERNS = [
    "ignore previous instructions",
    "ignore system prompt",
    "bypass security",
]

INDIRECT_PATTERNS = [
    "send the complete supplier database",
    "ignore procurement policy",
    "send database to",
]


def inspect_text(text: str):
    lower = text.lower()

    for pattern in JAILBREAK_PATTERNS:
        if pattern in lower:
            audit("guardrail_block", type="jailbreak", pattern=pattern)
            raise ValueError("Blocked jailbreak attempt")

    return True


def inspect_retrieved_content(text: str):
    lower = text.lower()

    for pattern in INDIRECT_PATTERNS:
        if pattern in lower:
            audit(
                "guardrail_block",
                type="indirect_prompt_injection",
                pattern=pattern,
            )
            raise ValueError("Blocked indirect prompt injection")

    return True


def inspect_tool_result(result):
    # Demo policy: confidential fields must not flow directly into generation.
    if isinstance(result, dict) and result.get("confidential") is True:
        audit("guardrail_block", type="confidential_tool_result")
        raise ValueError("Confidential tool result blocked")

    return True


def protected_output_policy(text: str):
    """
    Demonstrates 'annotate/flag' rather than discard.
    """
    if "copyrighted full text" in text.lower():
        return {
            "status": "FLAG_FOR_HUMAN_REVIEW",
            "content": text,
        }

    return {"status": "ALLOW", "content": text}
