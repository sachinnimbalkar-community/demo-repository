from unittest.mock import patch
from integrations import ollama


def test_ollama_prefers_configured_endpoint():
    with patch("integrations.ollama.health", side_effect=[True, False]):
        assert ollama.resolve_ollama_url() == ollama.OLLAMA_URL


def test_ollama_falls_back_to_11434():
    with patch("integrations.ollama.health", side_effect=[False, True]):
        assert ollama.resolve_ollama_url() == ollama.OLLAMA_FALLBACK_URL


def test_ollama_generate_uses_json_response():
    fake = {"response": "architecture answer"}
    with patch("integrations.ollama.resolve_ollama_url", return_value="http://localhost:11443"), \
         patch("integrations.ollama._post", return_value=fake):
        assert ollama.generate("test") == "architecture answer"
