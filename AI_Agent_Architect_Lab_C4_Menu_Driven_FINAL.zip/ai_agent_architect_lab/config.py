import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "runtime_data"
DATA_DIR.mkdir(exist_ok=True)

CHECKPOINT_FILE = DATA_DIR / "checkpoints.json"
AUDIT_FILE = DATA_DIR / "audit.jsonl"
TRACE_FILE = DATA_DIR / "traces.jsonl"

# Ollama:
# - Set OLLAMA_PORT=11443 if your local service uses 11443.
# - Otherwise the code falls back to Ollama's standard 11434.
# - OLLAMA_URL can override both.
OLLAMA_HOST = os.getenv("OLLAMA_HOST", "127.0.0.1")
OLLAMA_PORT = int(os.getenv("OLLAMA_PORT", "11443"))
OLLAMA_URL = os.getenv("OLLAMA_URL", f"http://{OLLAMA_HOST}:{OLLAMA_PORT}")
OLLAMA_FALLBACK_URL = os.getenv(
    "OLLAMA_FALLBACK_URL", f"http://{OLLAMA_HOST}:11434"
)
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2")
