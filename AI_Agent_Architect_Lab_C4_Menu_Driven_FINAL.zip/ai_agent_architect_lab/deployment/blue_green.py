class BlueGreenDeployment:
    def __init__(self):
        self.blue = "agent-platform-v1"
        self.green = "agent-platform-v2"
        self.active = self.blue

    def route(self):
        return self.active

    def switch_to_green(self):
        self.active = self.green

    def rollback(self):
        self.active = self.blue
