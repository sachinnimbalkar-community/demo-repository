# Architecture Story

## Request path

```text
User
  |
  v
API Gateway / Authentication
  |
  v
Supervisor / Router
  |
  +--> Input Guardrail
  |
  +--> RAG / Search
  |
  +--> Specialist Agent
  |       |
  |       v
  |   Tool Gateway / MCP
  |       |
  |       +--> Authorization
  |       +--> Typed validation
  |       +--> Rate limits
  |       |
  |       v
  |   Enterprise API
  |
  +--> Durable Checkpoint
  |
  +--> Output Guardrail
  |
  v
Response

Every stage emits trace/audit telemetry.
```

## Trust boundaries

1. User input is untrusted.
2. Retrieved documents are untrusted.
3. Tool results are untrusted unless explicitly classified as trusted.
4. The model is not an authorization boundary.
5. Tool gateways enforce authorization.
6. Model-generated arguments are validated before execution.
7. High-impact actions can pause for human approval.

## Identity

```text
fraud-agent   -> mi-fraud   -> fraud.read
payment-agent -> mi-payment -> payment.read/payment.write
customer-agent-> mi-customer-> customer.read/ticket.write
```

Avoid:

```text
All agents -> shared Contributor identity
```

## Production extensions

Replace the local adapters with:

- Azure Entra ID
- Azure Managed Identity
- Azure Key Vault
- Azure AI Search
- Cosmos DB
- Azure OpenAI / Microsoft Foundry
- MCP implementation
- Azure Monitor / Application Insights
- OpenTelemetry
- CI/CD and blue-green deployment
