# 20 Scenario Map

1. Tool isolation -> per-agent allowlists + identities + RBAC + typed validation
2. RAG chunking -> header-aware splitting
3. Indirect injection -> inspect retrieved content
4. Protected content -> block attacks, flag protected output
5. Secrets -> Key Vault + managed identity
6. Long workflows -> durable checkpoints
7. Context -> summarize/prune low-value history
8. Tool parameters -> validate before execution
9. Observability -> distributed tracing
10. Evaluation -> offline evaluation; monitoring in production
11. Model routing -> complexity-based routing
12. Handoff -> typed state contracts
13. CI -> deterministic mocks
14. MCP -> tool allowlist + boundary authorization
15. Identity -> per-agent least privilege
16. Retrieval -> investigate ranking/re-ranking
17. Guardrails -> input + tool-result boundaries
18. Deployment -> blue-green
19. Orchestration -> supervisor/agent-as-tools
20. Enterprise platform -> integrate all of the above

Use these as architecture interview prompts: explain the trust boundary,
failure mode, data flow, identity, observability, rollback strategy and
production trade-off.
