# AI Agent Architect Lab — Menu Driven C4 / Agentic AI Demo

A runnable, menu-driven reference implementation for practicing the 20 AI-500-style
architecture scenarios discussed in the conversation.

## What this demonstrates

1. Multi-agent tool isolation
2. Structure-aware RAG chunking
3. Indirect prompt-injection detection
4. Guardrail policy: block vs annotate
5. Secret rotation pattern with a Key Vault adapter
6. Durable workflow checkpoints
7. Context compaction
8. Typed tool-parameter validation
9. Distributed-trace style correlation
10. Offline evaluation vs production monitoring
11. Model routing
12. Typed agent handoff/state contracts
13. Deterministic CI testing with mocks
14. MCP/tool allowlisting
15. Per-agent identity / least privilege
16. Retrieval ranking / reranking
17. Guardrail placement
18. Blue-green deployment simulation
19. Supervisor orchestration
20. End-to-end enterprise architecture story

## Run

Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
source .venv/bin/activate

pip install -r requirements.txt
python main.py
```

No Azure subscription is required. The project uses local adapters/mocks so the
architecture can be demonstrated safely.

Optional Ollama integration:

1. Install Ollama separately.
2. Pull a local model, for example:
   `ollama pull llama3.2`
3. Start Ollama.
4. Select the Ollama option from the menu.

The core security controls do NOT depend on the model. The tool gateway,
authorization, typed validation, checkpoints and audit logging remain application
controls.

## Story

You are the AI Architect for a fictional bank called Contoso Bank.

A customer asks for help. The platform authenticates the request, routes it to
specialist agents, retrieves policy evidence, validates model-generated tool
requests, executes only authorized tools, checkpoints workflow state, records
traces, and evaluates the final result.

The menu lets you inspect each architectural control independently and then run
the complete end-to-end story.

## Project structure

```text
ai_agent_architect_lab/
├── main.py
├── requirements.txt
├── README.md
├── config.py
├── core/
│   ├── models.py
│   ├── audit.py
│   ├── tracing.py
│   ├── state.py
│   └── security.py
├── agents/
│   ├── base.py
│   ├── supervisor.py
│   ├── fraud.py
│   ├── payment.py
│   └── customer.py
├── rag/
│   ├── chunking.py
│   ├── retrieval.py
│   └── documents.py
├── tools/
│   ├── gateway.py
│   ├── payment.py
│   └── mcp.py
├── guardrails/
│   └── policies.py
├── evaluation/
│   └── evaluator.py
├── deployment/
│   └── blue_green.py
├── integrations/
│   └── ollama.py
├── tests/
│   └── test_architecture.py
└── docs/
    ├── ARCHITECTURE.md
    ├── SCENARIOS.md
    └── C4.md
```

## Architect takeaway

The central rule is:

> Do not make the LLM the security boundary. Build deterministic security
> boundaries around it.

The LLM can propose an action. The application decides whether that action is
authorized, whether its parameters are valid, whether the workflow can proceed,
and whether the result can be exposed.


## Ollama local LLM support

The lab does not require an LLM for the architecture/security tests. This is intentional:
authorization, typed validation, guardrails and checkpoints must remain deterministic.

For the optional LLM demonstration, the code:

1. Tries `OLLAMA_URL` if explicitly configured.
2. By default prefers `http://127.0.0.1:11443`.
3. Falls back automatically to `http://127.0.0.1:11434`.
4. Uses `OLLAMA_MODEL` (default `llama3.2`).

Examples:

```bash
# Standard Ollama
python main.py

# If Ollama is on 11443
OLLAMA_PORT=11443 python main.py

# Explicit endpoint
OLLAMA_URL=http://127.0.0.1:11443 python main.py

# Different local model
OLLAMA_MODEL=qwen2.5:7b python main.py
```

The menu option **21** checks Ollama and sends an architecture prompt.

### Recommended Ollama setup

```bash
ollama list
ollama pull llama3.2
ollama serve
```

If your Ollama installation is already running, do not start a second server on
the same port.

## Verification

Run:

```bash
python -m pytest -q
```

The test suite does not require Ollama to be running. Live Ollama is only needed
for menu option 21.
