from typing import Any, Literal
from pydantic import BaseModel, Field


class ToolCall(BaseModel):
    tool: str
    arguments: dict[str, Any]


class PaymentRequest(BaseModel):
    customer_id: str = Field(min_length=3)
    amount: float = Field(gt=0, le=100000)
    currency: Literal["INR", "USD", "EUR"] = "INR"


class RefundRequest(BaseModel):
    customer_id: str = Field(min_length=3)
    amount: float = Field(gt=0, le=100000)
    currency: Literal["INR", "USD", "EUR"] = "INR"


class FraudResult(BaseModel):
    customer_id: str
    risk: Literal["LOW", "MEDIUM", "HIGH"]
    evidence: list[str]
    required_action: Literal["AUTO_APPROVE", "MANUAL_REVIEW", "DECLINE"]


class WorkflowState(BaseModel):
    workflow_id: str
    customer_id: str
    request: str
    status: str = "STARTED"
    fraud: FraudResult | None = None
    payment_status: str | None = None
    retrieved_documents: list[str] = []
    decisions: list[str] = []
    completed_steps: list[str] = []
