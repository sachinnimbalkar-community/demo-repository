from core.audit import audit

AGENT_IDENTITIES = {
    "supervisor": "mi-supervisor",
    "fraud-agent": "mi-fraud",
    "payment-agent": "mi-payment",
    "customer-agent": "mi-customer",
}

AGENT_TOOLS = {
    "supervisor": {"getCustomer", "getFraudStatus", "getPaymentStatus"},
    "fraud-agent": {"getCustomer", "getFraudStatus"},
    "payment-agent": {"getCustomer", "getPaymentStatus", "createPayment", "refundPayment"},
    "customer-agent": {"getCustomer", "createTicket", "getTicketStatus"},
}

RBAC = {
    "mi-supervisor": {"customer.read", "fraud.read", "payment.read"},
    "mi-fraud": {"customer.read", "fraud.read"},
    "mi-payment": {"customer.read", "payment.read", "payment.write"},
    "mi-customer": {"customer.read", "ticket.read", "ticket.write"},
}


def authorize_tool(agent: str, tool: str):
    allowed = AGENT_TOOLS.get(agent, set())
    if tool not in allowed:
        audit("tool_denied", agent=agent, tool=tool)
        raise PermissionError(f"{agent} is not allowed to call {tool}")
    audit("tool_authorized", agent=agent, tool=tool)
    return True


def authorize_capability(agent: str, capability: str):
    identity = AGENT_IDENTITIES[agent]
    if capability not in RBAC[identity]:
        raise PermissionError(
            f"{identity} lacks RBAC capability {capability}"
        )
    return True
