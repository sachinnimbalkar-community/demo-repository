import json
import time
import uuid
from datetime import datetime, timezone
from config import TRACE_FILE


class Trace:
    def __init__(self, name: str, trace_id: str | None = None):
        self.trace_id = trace_id or str(uuid.uuid4())
        self.name = name
        self.started = time.perf_counter()
        self.spans = []

    def span(self, name: str, **attributes):
        start = time.perf_counter()

        class Span:
            def __enter__(inner):
                return inner

            def __exit__(inner, exc_type, exc, tb):
                duration_ms = round((time.perf_counter() - start) * 1000, 2)
                record = {
                    "trace_id": self.trace_id,
                    "span": name,
                    "duration_ms": duration_ms,
                    "attributes": attributes,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                }
                self.spans.append(record)
                with TRACE_FILE.open("a", encoding="utf-8") as f:
                    f.write(json.dumps(record) + "\n")

        return Span()

    def summary(self):
        return {
            "trace_id": self.trace_id,
            "duration_ms": round((time.perf_counter() - self.started) * 1000, 2),
            "spans": self.spans,
        }
