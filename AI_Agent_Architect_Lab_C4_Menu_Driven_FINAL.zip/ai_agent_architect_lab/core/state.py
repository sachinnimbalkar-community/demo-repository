import json
from config import CHECKPOINT_FILE
from core.models import WorkflowState


def _load_all():
    if not CHECKPOINT_FILE.exists():
        return {}
    return json.loads(CHECKPOINT_FILE.read_text(encoding="utf-8"))


def save_checkpoint(state: WorkflowState):
    data = _load_all()
    data[state.workflow_id] = state.model_dump()
    CHECKPOINT_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


def load_checkpoint(workflow_id: str) -> WorkflowState | None:
    data = _load_all()
    raw = data.get(workflow_id)
    return WorkflowState.model_validate(raw) if raw else None
