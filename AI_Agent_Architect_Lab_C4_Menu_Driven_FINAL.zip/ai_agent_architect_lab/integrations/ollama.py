import json
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from config import OLLAMA_URL, OLLAMA_FALLBACK_URL, OLLAMA_MODEL


def _post(url: str, payload: dict, timeout: int = 120):
    request = Request(
        url.rstrip("/") + "/api/generate",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def health(url: str, timeout: int = 3) -> bool:
    try:
        request = Request(url.rstrip("/") + "/api/tags", method="GET")
        with urlopen(request, timeout=timeout) as response:
            return response.status == 200
    except (URLError, HTTPError, TimeoutError, OSError):
        return False


def resolve_ollama_url():
    """
    Prefer 11443 (or OLLAMA_URL), then automatically fall back to 11434.
    This makes the lab work with either common local configuration.
    """
    if health(OLLAMA_URL):
        return OLLAMA_URL
    if OLLAMA_FALLBACK_URL != OLLAMA_URL and health(OLLAMA_FALLBACK_URL):
        return OLLAMA_FALLBACK_URL
    return None


def is_available():
    return resolve_ollama_url() is not None


def generate(prompt: str, model: str = OLLAMA_MODEL, timeout: int = 120):
    url = resolve_ollama_url()
    if not url:
        raise RuntimeError(
            "Ollama is not reachable on the configured port or default 11434. "
            "Start Ollama, then optionally set OLLAMA_PORT=11443 or OLLAMA_URL."
        )

    payload = {
        "model": model,
        "prompt": prompt,
        "stream": False,
    }
    data = _post(url, payload, timeout=timeout)
    return data.get("response", "")
