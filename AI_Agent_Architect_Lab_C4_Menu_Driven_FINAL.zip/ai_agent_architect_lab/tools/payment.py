from core.models import PaymentRequest, RefundRequest


class PaymentAPI:
    def create_payment(self, request: PaymentRequest):
        return {
            "status": "CREATED",
            "customer_id": request.customer_id,
            "amount": request.amount,
        }

    def refund(self, request: RefundRequest):
        return {
            "status": "REFUND_REQUESTED",
            "customer_id": request.customer_id,
            "amount": request.amount,
        }
