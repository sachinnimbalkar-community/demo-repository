from core.security import authorize_tool
from core.audit import audit
from core.models import PaymentRequest


class ToolGateway:
    """
    Deterministic security boundary between agents and tools.
    The LLM may propose a tool; the gateway decides whether execution is allowed.
    """

    def invoke(self, agent: str, tool: str, arguments: dict):
        authorize_tool(agent, tool)

        if tool == "createPayment":
            PaymentRequest.model_validate(arguments)
            audit("tool_validation_passed", agent=agent, tool=tool)
            return {
                "status": "CREATED",
                "tool": tool,
                "arguments": arguments,
            }

        if tool == "getPaymentStatus":
            return {"status": "PAID", "customer_id": arguments["customer_id"]}

        raise ValueError(f"Demo tool not implemented: {tool}")
