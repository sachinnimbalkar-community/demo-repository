from tools.gateway import ToolGateway


class MCPServer:
    """
    Minimal MCP-like demonstration.
    In production, transport/authentication/protocol details are provided by
    the MCP implementation. Authorization still belongs at the application
    or tool boundary.
    """

    def __init__(self):
        self.gateway = ToolGateway()

    def call(self, agent: str, tool: str, arguments: dict):
        return self.gateway.invoke(agent, tool, arguments)
