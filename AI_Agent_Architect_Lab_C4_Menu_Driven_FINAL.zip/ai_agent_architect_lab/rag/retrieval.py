from rag.documents import DOCUMENTS


def _score(query: str, doc: dict):
    words = set(query.lower().split())
    text = (doc["text"] + " " + " ".join(doc["tags"])).lower()
    return sum(1 for w in words if w in text)


def retrieve(query: str, top_k: int = 3):
    ranked = sorted(DOCUMENTS, key=lambda d: _score(query, d), reverse=True)
    return ranked[:top_k]


def hybrid_retrieve(query: str, top_k: int = 3):
    """
    Demo hybrid retrieval:
    keyword matching + simple semantic-like tag matching.
    A production system would use BM25 + vector search + metadata filters
    and often a reranker.
    """
    return retrieve(query, top_k=top_k)
