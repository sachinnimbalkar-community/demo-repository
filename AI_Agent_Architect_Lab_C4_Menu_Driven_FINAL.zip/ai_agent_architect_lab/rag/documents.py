DOCUMENTS = [
    {
        "title": "Payment Refund Policy",
        "text": "Refunds require a valid customer ID and positive refund amount. High-value refunds require manual review.",
        "tags": ["payment", "refund", "policy"],
    },
    {
        "title": "Fraud Monitoring Policy",
        "text": "Transaction velocity anomalies can trigger high fraud risk and manual review.",
        "tags": ["fraud", "risk", "policy"],
    },
    {
        "title": "Customer Support Runbook",
        "text": "Customer tickets should include customer ID, issue category and evidence.",
        "tags": ["support", "customer", "runbook"],
    },
]
