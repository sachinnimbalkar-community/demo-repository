import re


def header_aware_markdown_chunks(markdown: str):
    """
    Lightweight structure-aware splitter for the lab.
    Keeps H1/H2/H3 headings with their content.
    """
    lines = markdown.splitlines()
    chunks = []
    current = []

    for line in lines:
        if re.match(r"^#{1,3}\s+", line) and current:
            chunks.append("\n".join(current).strip())
            current = []
        current.append(line)

    if current:
        chunks.append("\n".join(current).strip())

    return [c for c in chunks if c]


if __name__ == "__main__":
    sample = """# Payments
## Refunds
Refund policy and process.
## Chargebacks
Chargeback procedure.
# Loans
## Eligibility
Eligibility rules."""
    for c in header_aware_markdown_chunks(sample):
        print("---")
        print(c)
