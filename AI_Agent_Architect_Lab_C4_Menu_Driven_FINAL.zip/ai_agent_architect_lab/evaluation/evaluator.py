from dataclasses import dataclass
from typing import Callable


@dataclass
class EvaluationCase:
    name: str
    input: str
    expected: str


CASES = [
    EvaluationCase(
        name="Fraud routing",
        input="Suspicious transaction velocity anomaly",
        expected="MANUAL_REVIEW",
    ),
    EvaluationCase(
        name="Normal request",
        input="Check my normal account status",
        expected="AUTO_APPROVE",
    ),
]


def evaluate(agent_fn: Callable):
    results = []

    for case in CASES:
        actual = agent_fn(case.input)
        passed = actual == case.expected
        results.append(
            {
                "case": case.name,
                "expected": case.expected,
                "actual": actual,
                "passed": passed,
            }
        )

    return results
