from agents.base import Agent
from core.models import PaymentRequest, RefundRequest
from core.security import authorize_capability
from core.audit import audit


class PaymentAgent(Agent):
    def __init__(self):
        super().__init__("payment-agent")

    def create_payment(self, payload: dict):
        authorize_capability(self.name, "payment.write")
        request = PaymentRequest.model_validate(payload)

        audit(
            "payment_created",
            customer_id=request.customer_id,
            amount=request.amount,
            currency=request.currency,
        )

        return {
            "status": "CREATED",
            "customer_id": request.customer_id,
            "amount": request.amount,
            "currency": request.currency,
        }

    def refund(self, payload: dict):
        authorize_capability(self.name, "payment.write")
        request = RefundRequest.model_validate(payload)

        audit(
            "refund_created",
            customer_id=request.customer_id,
            amount=request.amount,
            currency=request.currency,
        )

        return {
            "status": "REFUND_REQUESTED",
            "customer_id": request.customer_id,
            "amount": request.amount,
            "currency": request.currency,
        }
