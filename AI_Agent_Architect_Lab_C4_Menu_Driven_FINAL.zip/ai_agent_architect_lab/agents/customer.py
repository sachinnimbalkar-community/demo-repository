from agents.base import Agent
from core.security import authorize_capability


class CustomerAgent(Agent):
    def __init__(self):
        super().__init__("customer-agent")

    def get_customer(self, customer_id: str):
        authorize_capability(self.name, "customer.read")
        return {
            "customer_id": customer_id,
            "name": "Demo Customer",
            "segment": "Retail",
        }
