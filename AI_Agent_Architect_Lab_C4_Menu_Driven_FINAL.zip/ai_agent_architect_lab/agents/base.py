class Agent:
    def __init__(self, name: str):
        self.name = name

    def describe(self):
        return f"{self.name} agent"
