from agents.base import Agent
from core.models import FraudResult
from core.security import authorize_capability


class FraudAgent(Agent):
    def __init__(self):
        super().__init__("fraud-agent")

    def analyze(self, customer_id: str, request: str):
        authorize_capability(self.name, "fraud.read")

        # Deterministic demo logic.
        high_risk_words = ["suspicious", "velocity", "fraud", "multiple transactions"]
        high = any(x in request.lower() for x in high_risk_words)

        if high:
            return FraudResult(
                customer_id=customer_id,
                risk="HIGH",
                evidence=["transaction velocity anomaly"],
                required_action="MANUAL_REVIEW",
            )

        return FraudResult(
            customer_id=customer_id,
            risk="LOW",
            evidence=["no suspicious pattern detected in demo data"],
            required_action="AUTO_APPROVE",
        )
