from agents.fraud import FraudAgent
from agents.payment import PaymentAgent
from agents.customer import CustomerAgent
from core.models import WorkflowState
from core.state import save_checkpoint
from core.audit import audit
from core.tracing import Trace
from rag.retrieval import retrieve
from guardrails.policies import inspect_text, inspect_tool_result


class Supervisor:
    def __init__(self):
        self.fraud = FraudAgent()
        self.payment = PaymentAgent()
        self.customer = CustomerAgent()

    def run(self, state: WorkflowState):
        trace = Trace("bank-agent-workflow", state.workflow_id)

        with trace.span("input-guardrail"):
            inspect_text(state.request)

        with trace.span("customer-agent"):
            self.customer.get_customer(state.customer_id)

        with trace.span("rag-retrieval"):
            docs = retrieve(state.request)
            state.retrieved_documents = [d["title"] for d in docs]

        save_checkpoint(state)

        with trace.span("fraud-agent"):
            result = self.fraud.analyze(state.customer_id, state.request)
            state.fraud = result
            state.decisions.append(result.required_action)
            state.completed_steps.append("fraud")

        save_checkpoint(state)

        # Consequential action is not automatically executed for high-risk cases.
        if result.required_action == "MANUAL_REVIEW":
            state.status = "WAITING_FOR_HUMAN_APPROVAL"
            save_checkpoint(state)
            audit(
                "human_approval_required",
                workflow_id=state.workflow_id,
                reason="HIGH risk",
            )
            return {
                "status": state.status,
                "fraud": result.model_dump(),
                "trace": trace.summary(),
            }

        state.status = "COMPLETED"
        save_checkpoint(state)

        response = {
            "status": state.status,
            "message": "Demo workflow completed.",
            "fraud": result.model_dump(),
            "evidence": state.retrieved_documents,
        }

        inspect_tool_result(response)

        audit(
            "workflow_completed",
            workflow_id=state.workflow_id,
            status=state.status,
        )
        return {**response, "trace": trace.summary()}
